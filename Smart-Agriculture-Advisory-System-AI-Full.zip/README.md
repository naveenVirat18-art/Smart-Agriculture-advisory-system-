# Smart Agriculture Advisory System

Multi-page farmer advisory system with AI crop-photo diagnosis.

Pages:
index.html, home.html, crop.html, soil.html, soil-test.html, irrigation.html,
fertilizer.html, weather.html, pest.html, management.html, market.html

Backend:
server.js

Render:
Build Command: npm install
Start Command: npm start

Environment Variable:
GEMINI_API_KEY = your Gemini API key

The AI photo feature is on pest.html. It captures/selects a crop photo and sends it to the backend for analysis.

Important: a photo cannot reliably determine soil chemistry or an exact fertilizer dose. Confirm important disease/treatment decisions with local agricultural guidance and soil testing.
