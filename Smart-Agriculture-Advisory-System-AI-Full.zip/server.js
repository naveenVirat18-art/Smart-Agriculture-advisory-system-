const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 10000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const MODEL = "gemini-2.5-flash";

app.use(express.json({ limit: "12mb" }));
app.use(express.static(__dirname));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

app.get("/health", (req, res) => {
  res.json({ ok: true, geminiConfigured: Boolean(GEMINI_API_KEY) });
});

app.post("/api/analyze", async (req, res) => {
  try {
    if (!GEMINI_API_KEY) {
      return res.status(500).json({
        success: false,
        message: "GEMINI_API_KEY is not configured in Render."
      });
    }

    const { image, mimeType, cropHint } = req.body || {};
    if (!image) {
      return res.status(400).json({
        success: false,
        message: "No crop photo was received."
      });
    }

    const allowed = [
      "image/jpeg", "image/png", "image/webp",
      "image/heic", "image/heif"
    ];
    const safeMime = allowed.includes(mimeType) ? mimeType : "image/jpeg";

    const prompt = `
You are a cautious agricultural advisory assistant.

Analyze this crop/field photograph for a farmer.

Crop hint: ${cropHint || "not provided"}.

Return:
1. Visible crop/field type.
2. Irrigation guidance based on visible evidence and the crop if identifiable.
3. A possible disease, pest, nutrient deficiency, or other problem if visible.
4. Visible symptoms.
5. Safe immediate actions.
6. Fertilizer/nutrient guidance.

Rules:
- A single photograph cannot prove a diagnosis. Use wording such as "possible" when uncertain.
- If the image is unclear, say that clearly.
- Do not claim that a photo determines soil chemistry or N/P/K levels.
- Do not invent an exact fertilizer or pesticide dose.
- Recommend soil testing/local agricultural guidance for final fertilizer choice and dose.
- Do not recommend mixing pesticides or chemicals.
- Distinguish visible observations from inference.
- Keep the advice simple enough for a farmer.
`;

    const schema = {
      type: "object",
      properties: {
        crop_or_visible_field: { type: "string" },
        field_type: { type: "string" },
        confidence: { type: "string" },
        irrigation_advice: { type: "string" },
        possible_disease_or_problem: { type: "string" },
        symptoms: { type: "string" },
        immediate_actions: { type: "string" },
        fertilizer_guidance: { type: "string" },
        caution: { type: "string" }
      },
      required: [
        "crop_or_visible_field",
        "field_type",
        "confidence",
        "irrigation_advice",
        "possible_disease_or_problem",
        "symptoms",
        "immediate_actions",
        "fertilizer_guidance",
        "caution"
      ]
    };

    const apiUrl =
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`;

    const payload = {
      contents: [{
        parts: [
          { text: prompt },
          { inlineData: { mimeType: safeMime, data: image } }
        ]
      }],
      generationConfig: {
        temperature: 0.2,
        responseMimeType: "application/json",
        responseSchema: schema
      }
    };

    const response = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const raw = await response.text();

    if (!response.ok) {
      console.error("Gemini API error:", raw);
      return res.status(502).json({
        success: false,
        message: "AI service error. Check the Gemini API key in Render."
      });
    }

    const data = JSON.parse(raw);
    const text = data?.candidates?.[0]?.content?.parts
      ?.find(part => part.text)?.text;

    if (!text) {
      return res.status(502).json({
        success: false,
        message: "The AI returned no analysis."
      });
    }

    const analysis = JSON.parse(text);
    res.json({ success: true, analysis });

  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: "Server error while analyzing the photo."
    });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Smart Agriculture server running on port ${PORT}`);
});
