# Smart Agriculture Advisory System

## Render settings
- Environment: Node
- Build Command: `npm install`
- Start Command: `npm start`
- No environment variables are required for the no-OTP version.

The app serves `index.html` at `/` and all other HTML pages as static files.
